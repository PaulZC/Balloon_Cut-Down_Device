#ifndef sprint_float_h
#define sprint_float_h

unsigned char sprint_float(char *buffer, char *string, float value);

#endif
