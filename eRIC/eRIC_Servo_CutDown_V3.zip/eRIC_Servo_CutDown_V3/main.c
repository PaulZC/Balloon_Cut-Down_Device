/* Code for V3 of the Servo-Actuated Balloon Cut-Down Device
 *
 * Based extensively on the eRIC/eROS code examples kindly provided by LPRS:
 * http://www.lprs.co.uk/products/easyradio-ism-modules/eric-soc-rf-modules.html
 * http://www.lprs.co.uk/assets/files/eRIC4_9_Datasheet_1.34.pdf
 * http://www.lprs.co.uk/assets/files/Custom%20programming%20eRIC.zip
 * http://www.lprs.co.uk/knowledge-centre/code-examples.html
 * http://www.lprs.co.uk/assets/files/eRIC_LowPowerMode_V1.1.zip
 *
 * Uses Alan Carvalho de Assis' fork of Mikal Hart's TinyGPS to parse data from the u-blox CAM_M8 GNSS
 * https://github.com/acassis/tinygps
 *
 * Pin Allocations:
 * Pin 1 : CD - Unused [P2.4]
 * Pin 2 : CTS - Connected to the "Close" switch [P2.3]
 * Pin 3 : Connected to the "Open" switch - Serial RXD (Output) in bootloader mode [P2.2]
 * Pin 4 : Connected to the "-" switch - Serial TXD (Input) in bootloader mode [P2.1]
 * Pin 5 : RTS - Connected to the "+" switch [P2.0]
 * Pin 10: Enables 3.3V power for the CAM_M8 (Low = 3.3V is enabled)
 * Pin 11: Boot
 * Pin 12: Boot
 * Pin 13: Enables the MPM3610 5V regulator for the servo (High = 5V is enabled)
 * Pin 14: eRIC9 Frequency Select
 * Pin 15: UART Tx - connected to CAM_M8 RxD
 * Pin 16: LED
 * Pin 17: UART Rx - connected to CAM_M8 TxD
 * Pin 18: Servo PWM
 * Pin 19: Unused
 * Pin 20: Unused
 * Pin 21: Unused
 * Pin 22: ADC (Bus voltage / 4.3) [P2.5]
 *
 * GNSS is disabled (to save power) if the altitude limit is set to 99km
 *
 * The cut-down can be controlled via a radio packet:
 * The cut-down will open if it receives: its own serial number (8 ASCII Hex digits); its own serial number followed by "1"
 * The cut-down will close if it receives: its own serial number followed by "0"
 *
 * The altitude limit can be set via a radio packet if the cut-down receives its own serial number followed by "2xy"
 * where x is the 10km altitude limit and y is the 1km altitude limit.
 * I.e. the cut-down will open at xy000 metres
 * Setting the altitude to 99km will disable the CAM_M8
 *
 * If the cut-down receives its own serial number followed by "3" it will attempt to open the servo to the full extent of travel.
 * This could damage the servo and should only be used if the normal methods to open the cut-down have failed.
 *
 */

#define GNSS_LOW_POWER // Uncomment this line to enable GNSS low power mode
#define eRIC_RX_POWER // Uncomment this line to enable eRIC RX power saving
//#define TEST_ALT // Uncomment this line to set the altitude limit to TEST_ALT_LIM (and ignore the eeprom values)
//#define TEST_PWM // Uncomment this line to set the open and close PWM values for testing

#include <cc430f5137.h>
#include "eRIC.h"
#include <stdio.h>
#include <string.h>
#include "sprint_float.h"
#include "tinygps.h"
#include "LPRS_UART.h"
#include "ubx.h"

// Choose module type to ensure correct frequency selections
#define eRIC4
//#define   eRIC9

// Pin definitions
#define CAM_M8_On() Pin10_SetLow()
#define CAM_M8_Off() Pin10_SetHigh()
#define Servo_On() Pin13_SetHigh()
#define Servo_Off() Pin13_SetLow()
#define LED_On() Pin16_SetHigh()
#define LED_Off() Pin16_SetLow()
#define LED_Toggle() Pin16_Toggle()

#define CLOSE_Read() Pin2_Read()
#define OPEN_Read() Pin3_Read()
#define MINUS_Read() Pin4_Read()
#define PLUS_Read() Pin5_Read()
#define CLOSE 2
#define OPEN 3
#define MINUS 4
#define PLUS 5
#define MAX_ALT_OPENS 5 // Limit the number of opens-on-altitude to this value

// Eeprom memory locations
#define PREFIX 128
#define OPEN_PWM 129
#define CLOSE_PWM 130
#define ALT_LIM_10000 131
#define ALT_LIM_1000 132
#define CSUM 133

// Default values for eeprom and PWM limits
// 0.9msec = 30 cycles
// 1.5msec = 48 cycles
// 2.1msec = 67 cycles
#define DEFAULT_PWM 48
#define DEFAULT_OPEN_PWM DEFAULT_PWM // Default PWM values for normal operation
#define DEFAULT_CLOSE_PWM DEFAULT_PWM
#define PWM_MIN 30
#define PWM_MAX 67
#define DEFAULT_ALT_10000 3 // Default altitude limit * 10km
#define DEFAULT_ALT_1000 3 // Default altitude limit * 1km
#define PREFIX_VAL 0xA5 // 10100101 binary - just a random value, the actual value is not significant
#define MAX_VAL_FIX 30 // Limit for valid GNSS fixes (used to put CAM-M8 into low power mode; allow 5 mins (30 * 10secs))

// PWM setting for "death or glory", when the cut-down receives its own serial number followed by 3
#define DEATH_OR_GLORY PWM_MAX

#define TEST_ALT_LIM 110.0f // Test altitude limit
#define TEST_PWM_OPEN PWM_MAX // Servo open PWM during testing
#define TEST_PWM_CLOSE PWM_MIN // Servo close PWM during testing

// Globals
volatile unsigned char MySerial[] = {'0','0','0','0','0','0','0','0'}; // Storage for the eRIC serial number
volatile unsigned char RxData[] = {'F','F','F','F','F','F','F','F','F','F','F'}; /// Storage for received data
volatile unsigned char servo_pwm = DEFAULT_PWM; // Servo PWM setting
volatile unsigned char servo_open_pwm = DEFAULT_OPEN_PWM; // Servo PWM when open
volatile unsigned char servo_close_pwm = DEFAULT_CLOSE_PWM; // Servo PWM when closed
volatile unsigned char alt_lim_10000 = DEFAULT_ALT_10000; // GNSS Altitude Limit * 10km
volatile unsigned char alt_lim_1000 = DEFAULT_ALT_1000; // GNSS Altitude Limit * 1km
volatile unsigned char switch_int = 0; // Switch interrupt value
volatile unsigned char opens_on_altitude = 0; // How many times have we attempted to open above altitude limit
volatile unsigned char val_fix = 0; // How many valid fixes have been processed
volatile unsigned char ignore_GNSS = 0; // Flag to indicate if the GNSS should be ignored (powered down)

// Main

int main(void)
{
    // Set up the eRIC

    eRIC_WDT_Stop(); // Disable WDT
    eRIC_GlobalInterruptDisable(); // Global interrupts disabled

#ifdef eRIC4
    // eRIC4
    eROS_Initialise(434000000);       // eROS initialised at 434MHz
#else
    // eRIC9
    Pin14_SetAsInput(); // Pin14 is set as input for swapping frequency
    Pin14_PullUpEnable(); // Enable pull-up on Pin14
    if(Pin14_Read()) // If Pin14 is open
    {
        eROS_Initialise(869750000);       //eROS initilaised at 869.75MHz
    }
    else // Pin14 is shorted to GND
    {
        eROS_Initialise(915000000);       //eROS initilaised at 915.00MHz
    }
#endif

    eRIC_SetCpuFrequency(1048576); // Set CPU clock speed to 1.048576MHz. LPRS recommend this is done *after* eROS_Initialise

    unsigned char i = 0;
    while(i < 11) // Make sure RxData is clear
    {
        RxData[i++] = 'F';
    }

    eRIC_RfDataReceivedInterruptEnable(); // Enable Rf Data Rx interrupts
    eRIC_GlobalInterruptEnable(); // Enable interrupts

    eRIC_Rx_Enable(); // Enable receiver
    eRIC_ChannelSpacing = 100000; // Set channel spacing to 100kHz
    eRIC_Channel = 5; // Set channel 5
    eRIC_RfBaudRate = 1200; // Set over air baud rate to 1200
    eRIC_Power = 0; // Set transmit power to 0dBm
    eRIC_TxPowerLevel = 2; // Set Tx power saving (increases preamble length)
    eRIC_RadioUpdate(); // Update the settings

    // Set up the I/O pins

    Pin1_InterruptDisable(); // Make sure Pin 1 cannot interrupt (redundant?)
    Pin1_FunctionNone(); // Pin1 is unused

    Pin2_FunctionNone(); // (redundant?)
    Pin2_FunctionIO(); // (redundant?)
    Pin2_SetAsInput(); // Set Pin2 as Input for the CLOSE switch
    Pin2_PullUpEnable(); // Enable pull-up on Pin2

    Pin3_FunctionNone(); // (redundant?)
    Pin3_FunctionIO(); // (redundant?)
    Pin3_SetAsInput(); // Set Pin2 as Input for the OPEN switch
    Pin3_PullUpEnable(); // Enable pull-up on Pin3

    Pin4_FunctionNone(); // (redundant?)
    Pin4_FunctionIO(); // (redundant?)
    Pin4_SetAsInput(); // Set Pin2 as Input for the minus switch
    Pin4_PullUpEnable(); // Enable pull-up on Pin4

    Pin5_FunctionNone(); // (redundant?)
    Pin5_FunctionIO(); // (redundant?)
    Pin5_SetAsInput(); // Set Pin2 as Input for the plus switch
    Pin5_PullUpEnable(); // Enable pull-up on Pin5

    Pin10_SetAsOutput(); // Set Pin10 as Output to enable 3.3V for the CAM_M8
    CAM_M8_Off(); // Disable the CAM_M8

    Pin13_SetAsOutput(); // Set Pin13 as Output to enable 5V for the servo
    Servo_Off(); // Disable the servo

    Pin15_FunctionNone(); // (redundant?)
    Pin15_FunctionUartATxOUT() // Make Pin15 UART TxD for serial data to the CAM_M8

    Pin16_FunctionNone(); // (redundant?)
    Pin16_FunctionIO(); // (redundant?)
    Pin16_SetAsOutput(); // Set Pin16 as Output to drive LED
    LED_Off(); // Disable LED

    Pin17_FunctionNone(); // (redundant?)
    Pin17_FunctionUartARxD(); // Make Pin17 UART RxD for serial data from the CAM_M8

    Pin18_FunctionNone(); // (redundant?)
    Pin18_FunctionPWM1(); // Make Pin18 the PWM output for the servo

    Pin19_FunctionNone(); // Pin19 is unused
    Pin20_FunctionNone(); // Pin20 is unused
    Pin21_FunctionNone(); // Pin21 is unused

    // ADC for bus voltage
    // The voltage on Pin22 is the bus divided by 4.3
    Pin22_InterruptDisable(); // Make sure Pin 22 cannot interrupt (redundant?)
    Pin22_FunctionNone(); // (redundant?)
    Pin22_FunctionA2D(); // Set Pin22 as ADC to read bus voltage
    eRIC_SetAdcPin(22); //Set Pin22 as ADC
    eRIC_SetAdcRefVoltage(eRICADCRef_2_5v,0); // Set reference to 2.5V

    // Record switch state at reset (to see if we need to set the servo position or altitude limit)
    unsigned char switch_state = 0;
    if (PLUS_Read() == 0) switch_state |= 0x01; // Read plus switch
    if (MINUS_Read() == 0) switch_state |= 0x02; // Read minus switch
    if (OPEN_Read() == 0) switch_state |= 0x04; // Read open switch
    if (CLOSE_Read() == 0) switch_state |= 0x08; // Read close switch

    // Initialise eeprom values if required
    // First read the values
    unsigned char eeprom_prefix = eRIC_Eeprom_Read(PREFIX); // Read prefix from eeprom
    unsigned char eeprom_open_pwm = eRIC_Eeprom_Read(OPEN_PWM); // Read open_pwm value from eeprom
    unsigned char eeprom_close_pwm = eRIC_Eeprom_Read(CLOSE_PWM); // Read close_pwm value from eeprom
    unsigned char eeprom_alt_lim_10000 = eRIC_Eeprom_Read(ALT_LIM_10000); // Read 10km altitude limit from eeprom
    unsigned char eeprom_alt_lim_1000 = eRIC_Eeprom_Read(ALT_LIM_1000); // Read 1km altitude limit from eeprom
    unsigned char eeprom_csum = eRIC_Eeprom_Read(CSUM); // Read checksum from eeprom
    // Check the checksum
    unsigned int csum = eeprom_prefix + eeprom_open_pwm + eeprom_close_pwm + eeprom_alt_lim_10000 + eeprom_alt_lim_1000;
    // Check if data is valid
    csum = csum & 0xFF; // Limit checksum to 8 bits
    // Check if the eeprom data is valid (check if the prefix and checksum both match)
    if ((eeprom_prefix != PREFIX_VAL) || ((unsigned char)csum != eeprom_csum))
    {
        // eeprom data is invalid so initialise it
        servo_open_pwm = DEFAULT_OPEN_PWM; // Initialise the open_pwm
        servo_close_pwm = DEFAULT_CLOSE_PWM; // Initialise the close_pwm
        alt_lim_10000 = DEFAULT_ALT_10000; // Initialise the 10km altitude limit
        alt_lim_1000 = DEFAULT_ALT_1000; // Initialise the 1km altitude limit
        eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Initialise the eeprom prefix
        eRIC_Eeprom_Write(OPEN_PWM, DEFAULT_OPEN_PWM); // Initialise the eeprom open_pwm
        eRIC_Eeprom_Write(CLOSE_PWM, DEFAULT_CLOSE_PWM); // Initialise the eeprom close_pwm
        eRIC_Eeprom_Write(ALT_LIM_10000, DEFAULT_ALT_10000); // Initialise the eeprom 10km altitude limit
        eRIC_Eeprom_Write(ALT_LIM_1000, DEFAULT_ALT_1000); // Initialise the eeprom 1km altitude limit
        csum = PREFIX_VAL + DEFAULT_OPEN_PWM + DEFAULT_CLOSE_PWM + DEFAULT_ALT_10000 + DEFAULT_ALT_1000; // Calculate the checksum
        csum = csum & 0xFF; // Limit checksum to 8 bits
        eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Initialise the eeprom checksum
    }
    else
    {
        // eeprom data is valid so use it
        servo_open_pwm = eeprom_open_pwm; // Use the open_pwm from eeprom
        servo_close_pwm = eeprom_close_pwm; // Use the close_pwm value from eeprom
        alt_lim_10000 = eeprom_alt_lim_10000; // Use the 10km altitude limit from eeprom
        alt_lim_1000 = eeprom_alt_lim_1000; // Use the 1km altitude limit from eeprom
    }

    // Set PWM to 50Hz with 1.5msec pulse width to centre the servo
    // Pulse duration is from 0.9msec to 2.1msec with 1.5msec as centre. The pulse refreshes at 50Hz (20msec).
    // Use 32kHz clock to keep pulse width values less than 256 so they can be stored in a single EEPROM location
    // 20msec = 640 cycles (produces 51.0 Hz, 654 produces 50 Hz)
    // 0.9msec = 30 cycles
    // 1.5msec = 48 cycles
    // 2.1msec = 67 cycles
    servo_pwm = DEFAULT_PWM;
    eRIC_PWM_Setup(eRICPWM_Cs_32k,eRICPWM_DIV_1,eRICPWM_UpMode,654); //Set PWM with 32kHz clock source and Upmode and period of 20msec.
    eRIC_PWM1_DutyCycle(servo_pwm,eRICPWM_OutputMode_Reset_Set); // Set default duty cycle (pulse width = 1.5msec)


    // Check if (only) the plus switch was pressed on reset (to see if we need to set the servo positions)
    // If so, change and store the servo positions in eeprom, and wait for reset
    if (switch_state == 0x01) // Check if only the plus switch was low
    {
        while (PLUS_Read() == 0) ; // Wait for plus switch to be released
        Servo_On(); // Enable 5V for the servo, it will move to default position
        while (1) // Keep doing this until reset
        {
            unsigned char decOne = 0; // Flag to indicate that PWM should be decremented by one
            unsigned char incOne = 0; // Flag to indicate that PWM should be incremented by one
            unsigned char plusSwitchState = PLUS_Read(); // Read the plus switch state
            unsigned char minusSwitchState = MINUS_Read(); // Read the minus switch state
            if ((plusSwitchState == 0) && (minusSwitchState > 0)) // If only the plus switch is pressed (low)
            {
                incOne = 1;
            }
            else if ((plusSwitchState > 0) && (minusSwitchState == 0)) // If only the minus switch is pressed (low)
            {
                decOne = 1;
            }
            // (If neither or both switches are pressed, do nothing)

            if ((incOne == 1) || (decOne == 1)) // If either switch was pressed
            {
                if (decOne == 1) // this inverts the servo movement direction
                {
                    if (servo_pwm < PWM_MAX) // Check if the maximum PWM limit has been reached
                    {
                        servo_pwm = servo_pwm + 1; // If not, increment the pwm value
                    }
                }
                else
                {
                    if (servo_pwm > PWM_MIN) // Check if the minimum PWM limit has been reached
                    {
                        servo_pwm = servo_pwm - 1; // If not, decrement the pwm value
                    }
                }
            }
            eRIC_PWM1_DutyCycle(servo_pwm,eRICPWM_OutputMode_Reset_Set); // Update PWM duty cycle
            eRIC_Delay(100); // Wait (BLOCKING!)
            unsigned char updateEeprom = 0; // Flag to indicate that the eeprom should be updated
            unsigned char openSwitchState = OPEN_Read(); // Read the open switch state
            unsigned char closeSwitchState = CLOSE_Read(); // Read the close switch state
            if ((openSwitchState == 0) && (closeSwitchState > 0)) // If only the open switch is pressed (low)
            {
                updateEeprom = 1; // Flag that eeprom needs updating
                servo_open_pwm = servo_pwm; // Update the open_pwm value
            }
            else if ((openSwitchState > 0) && (closeSwitchState == 0)) // If only the close switch is pressed (low)
            {
                updateEeprom = 1; // Flag that the eeprom needs updating
                servo_close_pwm = servo_pwm; // Update the close_pwm value
            }
            if (updateEeprom == 1) // If either switch was pressed, update eeprom
            {
                eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                eRIC_Eeprom_Write(OPEN_PWM, servo_open_pwm); // Update the eeprom open_pwm value
                eRIC_Eeprom_Write(CLOSE_PWM, servo_close_pwm); // Update the eeprom close_pwm value
                eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                csum = PREFIX_VAL + servo_open_pwm + servo_close_pwm + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                csum = csum & 0xFF; // Limit checksum to 8 bits
                eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                // Flash the LED to show data has been written to eeprom
                LED_On();
                eRIC_Delay(2000);
                LED_Off();
                eRIC_Delay(1000);
            }
            while ((openSwitchState == 0) || (closeSwitchState == 0)) // Wait for both switches to be released
            {
                openSwitchState = OPEN_Read(); // Read the open switch state
                closeSwitchState = CLOSE_Read(); // Read the close switch state
            }
        }
    }


    // Check if (only) the minus switch was pressed on reset (to see if we need to set the altitude limits)
    // If so, change and store the altitude limits in eeprom, and wait for reset
    if (switch_state == 0x02) // Check if minus bit was low
    {
        while (MINUS_Read() == 0) ; // Wait for switch to be released

        unsigned char alt_val = 3; // Initial value for the altitude limit

        while (1) // Keep doing this until reset
        {
            i = 0;
            unsigned char flash_state = alt_val * 4; // Use alt_val * 4 to control 100msec LED flashing
            switch_state = 0x00; // Clear the record of the switch state
            while (i < flash_state) // Flash the LED alt_val times while monitoring for switch presses
            {
                // Record switch state to see if we need to change or set the altitude limit
                if (PLUS_Read() == 0) switch_state |= 0x01; // Keep a record of whether plus switch has been pressed
                if (MINUS_Read() == 0) switch_state |= 0x02; // Keep a record of whether minus switch has been pressed
                if (OPEN_Read() == 0) switch_state |= 0x04; // Keep a record of whether open switch has been pressed
                if (CLOSE_Read() == 0) switch_state |= 0x08; // Keep a record of whether close switch has been pressed
                if (switch_state != 0x00) // If any switch is pressed
                {
                    i = flash_state; // Stop flashing if any switch has been pressed
                    break;
                }
                if ((i % 4) < 2) // Flash the LED on for two 100msec periods, then off for two 100msec periods
                {
                    LED_On();
                }
                else
                {
                    LED_Off();
                }
                eRIC_Delay(100); // Delay (BLOCKING!)
                i++;
            }
            LED_Off(); // Make sure LED is off
            i = 0;
            while (i < 10) // Keep LED off for one second while monitoring switches (every 100msec)
            {
                // Record switch state to see if we need to change or set the altitude limit
                if (PLUS_Read() == 0) switch_state |= 0x01; // Keep a record of whether plus switch has been pressed
                if (MINUS_Read() == 0) switch_state |= 0x02; // Keep a record of whether minus switch has been pressed
                if (OPEN_Read() == 0) switch_state |= 0x04; // Keep a record of whether open switch has been pressed
                if (CLOSE_Read() == 0) switch_state |= 0x08; // Keep a record of whether close switch has been pressed
                if (switch_state != 0x00) // If any switch is pressed
                {
                    i = 10; // Stop flashing if any switch has been pressed
                    break;
                }
                eRIC_Delay(100); // Delay (BLOCKING!)
                i++;
            }
            if (switch_state == 0x01) // If only the plus switch was pressed
            {
                if (alt_val < 9) // Limit alt_val to 9
                {
                    alt_val = alt_val + 1; // Increase alt_val by one
                }
            }
            else if (switch_state == 0x02) // If only the minus switch was pressed
            {
                if (alt_val > 0) // Do not allow alt_val to go negative
                {
                    alt_val = alt_val - 1; // Decrease alt_val by one
                }
            }
            else if (switch_state == 0x04) // If only the open switch was pressed
            {
                // Update alt_lim_1000 and write to eeprom
                alt_lim_1000 = alt_val;

                eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                eRIC_Eeprom_Write(OPEN_PWM, servo_open_pwm); // Update the eeprom open_pwm value
                eRIC_Eeprom_Write(CLOSE_PWM, servo_close_pwm); // Update the eeprom close_pwm value
                eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                csum = PREFIX_VAL + servo_open_pwm + servo_close_pwm + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                csum = csum & 0xFF; // Limit checksum to 8 bits
                eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                // Flash the LED to show data has been written to eeprom
                LED_On();
                eRIC_Delay(2000);
                LED_Off();
                eRIC_Delay(1000);
            }
            else if (switch_state == 0x08) // If only the open switch was pressed
            {
                // Update alt_lim_10000 and write to eeprom
                alt_lim_10000 = alt_val;

                eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                eRIC_Eeprom_Write(OPEN_PWM, servo_open_pwm); // Update the eeprom open_pwm value
                eRIC_Eeprom_Write(CLOSE_PWM, servo_close_pwm); // Update the eeprom close_pwm value
                eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                csum = PREFIX_VAL + servo_open_pwm + servo_close_pwm + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                csum = csum & 0xFF; // Limit checksum to 8 bits
                eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                // Flash the LED to show data has been written to eeprom
                LED_On();
                eRIC_Delay(2000);
                LED_Off();
                eRIC_Delay(1000);
            }
            if (switch_state > 0) // If any switch was pressed, wait for it to be released
            {
                while (switch_state > 0)
                {
                    switch_state = 0;
                    if (PLUS_Read() == 0) switch_state |= 0x01; // Keep a record of whether plus switch has been pressed
                    if (MINUS_Read() == 0) switch_state |= 0x02; // Keep a record of whether minus switch has been pressed
                    if (OPEN_Read() == 0) switch_state |= 0x04; // Keep a record of whether open switch has been pressed
                    if (CLOSE_Read() == 0) switch_state |= 0x08; // Keep a record of whether close switch has been pressed
                }
            }
        }
    }


    // Flash the LED to show altitude limit
    i = 0;
    if (alt_lim_10000 > 0) // Is the 10km altitude limit > 0 ?
    {
        while (i < alt_lim_10000) // If so, flash the LED alt_lim times
        {
            LED_On();
            eRIC_Delay(200);
            LED_Off();
            eRIC_Delay(200);
            i++;
        }
    }
    else
    {
        LED_On(); // Replace zero with a long flash
        eRIC_Delay(2000);
        LED_Off();
    }
    eRIC_Delay(1000); // Pause for 1 sec
    i = 0;
    if (alt_lim_1000 > 0) // Is the 1km altitude limit > 0 ?
    {
        while (i < alt_lim_1000) // If so, now flash the LED alt_lim times
        {
            LED_On();
            eRIC_Delay(200);
            LED_Off();
            eRIC_Delay(200);
            i++;
        }
    }
    else
    {
        LED_On(); // Replace zero with a long flash
        eRIC_Delay(2000);
        LED_Off();
    }

    // Put the eRIC into RX power saving if required now that eeprom access is complete
#ifdef eRIC_RX_POWER
    eRIC_RxPowerLevel = 2; // Set Rx power saving (reduces receiver duty cycle)
    eRIC_RadioUpdate(); // Update the settings
#endif

    // Get the eRIC serial number and transmit it together with the altitude limit

    eRIC_RadioTx_BuffCount = 0; // Reset the Tx buffer counter
    unsigned long sernum = eRIC_GetSerialNumber(); // Get the eRIC serial number
    unsigned char nibble = (unsigned char)((sernum >> 28) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 24) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 20) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 16) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 12) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 8) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)((sernum >> 4) & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (unsigned char)(sernum & 0xF); // Select a nibble
    nibble = (nibble < 10 ? '0' : 'A' - 10) + nibble; // Convert it to ASCII
    MySerial[eRIC_RadioTx_BuffCount] = nibble; // Store it
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter

    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = ' '; // Add a space to Tx buffer
    nibble = (alt_lim_10000 & 0x0F) + '0'; // Add alt_lim_10000 to the buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    nibble = (alt_lim_1000 & 0x0F) + '0'; // Add alt_lim_1000 to the buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = nibble; // Add to the Tx buffer and increment the counter
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = '0'; // Add a zero to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = '0'; // Add a zero to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = '0'; // Add a zero to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = 'm'; // Add 'm' to Tx buffer
    eRIC_RadioTx_Buffer[eRIC_RadioTx_BuffCount++] = 0x0A; // Add a new line character to Tx buffer

    eRIC_RfSenddata(); // Transmit the serial number
    while(eRIC_RadioTx_BuffCount); // Wait for Tx to finish (eRIC_RfSenddata resets eRIC_RadioTx_BuffCount to zero when complete)

    // Check if the altitude limit has been set to 99km. If it has, set ignore_GNSS to 1
    ignore_GNSS = 0;
    if ((alt_lim_10000 == 9) && (alt_lim_1000 == 9))
    {
        ignore_GNSS = 1;
    }

    // Initialise the UART and TinyGPS so both are ready now or later
    UARTinit();
    gps_init();

    if (!ignore_GNSS) // Check if we are ignoring the GNSS
    {
        // Power up the CAM_M8
        CAM_M8_On(); // Enable the CAM_M8
        eRIC_Delay(2000); // Let the CAM_M8 power up

        // Initialise the M8 by clearing the stored configuration and then loading it
        sendUBX(clearConf, len_Conf); // Clear stored configuration
        eRIC_Delay(100);
        sendUBX(loadConf, len_Conf); // Load configuration
        eRIC_Delay(2100);

        // Disable all GNSS NMEA messages
        UART_Println("$PUBX,40,GLL,0,0,0,0*5C"); // Disable GLL
        eRIC_Delay(100);
        UART_Println("$PUBX,40,ZDA,0,0,0,0*44"); // Disable ZDA
        eRIC_Delay(100);
        UART_Println("$PUBX,40,VTG,0,0,0,0*5E"); // Disable VTG
        eRIC_Delay(100);
        UART_Println("$PUBX,40,GSV,0,0,0,0*59"); // Disable GSV
        eRIC_Delay(100);
        UART_Println("$PUBX,40,GSA,0,0,0,0*4E"); // Disable GSA
        eRIC_Delay(100);
        UART_Println("$PUBX,40,RMC,0,0,0,0*47"); // Disable RMC
        eRIC_Delay(100);
        //UART_Println("$PUBX,40,GGA,0,1,0,0*5B"); // Send GGA every 1 seconds
        //UART_Println("$PUBX,40,GGA,0,2,0,0*58"); // Send GGA every 2 seconds
        //UART_Println("$PUBX,40,GGA,0,5,0,0*5F"); // Send GGA every 5 seconds
        UART_Println("$PUBX,40,GGA,0,10,0,0*6B"); // Send GGA every 10 seconds
        eRIC_Delay(100);
        sendUBX(disableTimePulse, len_setTimePulse); // Disable Time Pulse
        eRIC_Delay(100);
        sendUBX(setNavAir, len_setNav); // Set Airborne <1G Navigation Mode
        eRIC_Delay(100);
        sendUBX(setNMEA, len_setNMEA); // Set NMEA configuration (use GP prefix instead of GN otherwise parsing will fail)
        eRIC_Delay(100);
        sendUBX(setGNSS, len_setGNSS); // Set GNSS - causes a reset of the M8!
        eRIC_Delay(3100);

        // Clear the UART Rx buffer to erase ubx acknowledgements
        UARTclearRxBuffer();

        opens_on_altitude = 0; // Make sure opens_on_altitude is initialised
        val_fix = 0; // Make sure the number of valid fixes is initialised
    }


    // Enable open and close switch interrupts
    switch_int = 0;
    Pin2_InterruptHigh2Low(); // High-to-low interrupts on Pin2
    Pin2_ClearInterruptFlag(); // Clear interrupt flag before enabling interrupt
    Pin2_InterruptEnable(); // Enable interrupt on Pin2
    Pin3_InterruptHigh2Low(); // High-to-low interrupts on Pin3
    Pin3_ClearInterruptFlag(); // Clear interrupt flag before enabling interrupt
    Pin3_InterruptEnable(); // Enable interrupt on Pin3

    // Enter the actual main loop

    while(1) // Loop continuously
    {
        // Check for a switch interrupt
        // If a switch has been pressed, open or close the servo as required
        if (switch_int > 0)
        {
            if (switch_int == OPEN) // If the open switch was pressed
            {
#ifdef TEST_PWM
                eRIC_PWM1_DutyCycle(TEST_PWM_OPEN,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#else
                eRIC_PWM1_DutyCycle(servo_open_pwm,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#endif
                Servo_On(); // Enable 5V for the servo
                eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
                Servo_Off(); // Disable the servo
            }
            else if (switch_int == CLOSE) // If the close switch was pressed
            {
#ifdef TEST_PWM
                eRIC_PWM1_DutyCycle(TEST_PWM_CLOSE,eRICPWM_OutputMode_Reset_Set); // Set PWM to close
#else
                eRIC_PWM1_DutyCycle(servo_close_pwm,eRICPWM_OutputMode_Reset_Set); // Set PWM to close
#endif
                Servo_On(); // Enable 5V for the servo
                eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
                Servo_Off(); // Disable the servo
            }
            switch_int = 0; // clear the interrupt flag
        }


        // Compare RxData to MySerial, check for a match
        // If the data matches, open or close the servo as required
        volatile int match = 1; // Flag to indicate a match. Initialise as true.
        // First check for the eRIC serial number on its own
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i+3] != MySerial[i]) // If the data does not match (include 3 char offset)
            {
                match = 0; // Clear the flag
                break; // Exit the while loop
            }
            i++;
        }
        if (match) // If the data matches, open the servo
        {
#ifdef TEST_PWM
                eRIC_PWM1_DutyCycle(TEST_PWM_OPEN,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#else
                eRIC_PWM1_DutyCycle(servo_open_pwm,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#endif
            Servo_On(); // Enable 5V for the servo
            eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
            Servo_Off(); // Disable the servo
            i = 0;
            while(i < 11) // Clear RxData
            {
                RxData[i++] = 'F';
            }
        }
        // Next check for the eRIC serial number followed by '0', '1' or '3'
        match = 1;
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i+2] != MySerial[i]) // If the data does not match
            {
                match = 0; // Clear the flag
                break; // Exit the while loop
            }
            i++;
        }
        if (match) // If the serial number matches
        {
            if (RxData[10] == '1') // Check for a following '1'
            {
#ifdef TEST_PWM
                eRIC_PWM1_DutyCycle(TEST_PWM_OPEN,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#else
                eRIC_PWM1_DutyCycle(servo_open_pwm,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#endif
                Servo_On(); // Enable 5V for the servo
                eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
                Servo_Off(); // Disable the servo
            }
            if (RxData[10] == '0') // Check for a following '0'
            {
#ifdef TEST_PWM
                eRIC_PWM1_DutyCycle(TEST_PWM_CLOSE,eRICPWM_OutputMode_Reset_Set); // Set PWM to close
#else
                eRIC_PWM1_DutyCycle(servo_close_pwm,eRICPWM_OutputMode_Reset_Set); // Set PWM to close
#endif
                Servo_On(); // Enable 5V for the servo
                eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
                Servo_Off(); // Disable the servo
            }
            if (RxData[10] == '3') // Check for a following '3'
            {
                eRIC_PWM1_DutyCycle(DEATH_OR_GLORY,eRICPWM_OutputMode_Reset_Set); // Set PWM to "death or glory"!
                Servo_On(); // Enable 5V for the servo
                eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
                Servo_Off(); // Disable the servo
            }
            i = 0;
            while(i<11) // Clear RxData since we found a match
            {
                RxData[i++] = 'F';
            }
        }
        // Now check for the eRIC serial number followed by "2" and the altitude limit
        match = 1;
        i = 0;
        while(i < 8) // For each of the eight bytes
        {
            if (RxData[i] != MySerial[i]) // If the data does not match
            {
                match = 0; // Clear the flag
                break; // Exit the while loop
            }
            i++;
        }
        if (match) // If the data matches, check for "2" followed by two 0-9 digits
        {
            if (RxData[8] == '2') // Check for a following '2'
            {
                // Check that "00" to "99" follows
                if (((RxData[9] >= '0') && (RxData[9] <= '9')) && ((RxData[10] >= '0') && (RxData[10] <= '9')))
                {
                    // Disable Rx power saving to allow eeprom writes
                    eRIC_RxPowerLevel = 0; // Disable Rx power saving (enables eeprom writes)
                    eRIC_RadioUpdate(); // Update the settings
                    // Update alt_lim_10000 and alt_lim_1000 and write to eeprom
                    alt_lim_10000 = RxData[9] - '0';
                    alt_lim_1000 = RxData[10] - '0';
                    eRIC_Eeprom_Write(PREFIX, PREFIX_VAL); // Update the eeprom prefix
                    eRIC_Eeprom_Write(OPEN_PWM, servo_open_pwm); // Update the eeprom open_pwm value
                    eRIC_Eeprom_Write(CLOSE_PWM, servo_close_pwm); // Update the eeprom close_pwm value
                    eRIC_Eeprom_Write(ALT_LIM_10000, alt_lim_10000); // Update the eeprom 10km altitude limit
                    eRIC_Eeprom_Write(ALT_LIM_1000, alt_lim_1000); // Update the eeprom 1km altitude limit
                    csum = PREFIX_VAL + servo_open_pwm + servo_close_pwm + alt_lim_10000 + alt_lim_1000; // Calculate the checksum
                    csum = csum & 0xFF; // Limit checksum to 8 bits
                    eRIC_Eeprom_Write(CSUM, (unsigned char)csum); // Update the eeprom checksum
                    // Re-enable Rx power saving
#ifdef eRIC_RX_POWER
                    eRIC_RxPowerLevel = 2; // Set Rx power saving (reduces receiver duty cycle and disables eeprom writes)
                    eRIC_RadioUpdate(); // Update the settings
#endif
                    // Check if a new altitude limit of 99km was received
                    // If it was, disable the GNSS
                    if ((alt_lim_10000 == 9) && (alt_lim_1000 == 9))
                    {
                        CAM_M8_Off();
                        ignore_GNSS = 1;
                    }
                    else if (ignore_GNSS == 1)
                        // If the new altitude limit is not 99km and ignore_GNSS is already set
                        // then (re)start the CAM_M8
                    {
                        // Power up the CAM_M8
                        CAM_M8_On(); // Enable the CAM_M8
                        eRIC_Delay(2000); // Let the CAM_M8 power up

                        // Initialise the M8 by clearing the stored configuration and then loading it
                        sendUBX(clearConf, len_Conf); // Clear stored configuration
                        eRIC_Delay(100);
                        sendUBX(loadConf, len_Conf); // Load configuration
                        eRIC_Delay(2100);

                        // Disable all GNSS NMEA messages
                        UART_Println("$PUBX,40,GLL,0,0,0,0*5C"); // Disable GLL
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,ZDA,0,0,0,0*44"); // Disable ZDA
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,VTG,0,0,0,0*5E"); // Disable VTG
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,GSV,0,0,0,0*59"); // Disable GSV
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,GSA,0,0,0,0*4E"); // Disable GSA
                        eRIC_Delay(100);
                        UART_Println("$PUBX,40,RMC,0,0,0,0*47"); // Disable RMC
                        eRIC_Delay(100);
                        //UART_Println("$PUBX,40,GGA,0,1,0,0*5B"); // Send GGA every 1 seconds
                        //UART_Println("$PUBX,40,GGA,0,2,0,0*58"); // Send GGA every 2 seconds
                        //UART_Println("$PUBX,40,GGA,0,5,0,0*5F"); // Send GGA every 5 seconds
                        UART_Println("$PUBX,40,GGA,0,10,0,0*6B"); // Send GGA every 10 seconds
                        eRIC_Delay(100);
                        sendUBX(disableTimePulse, len_setTimePulse); // Disable Time Pulse
                        eRIC_Delay(100);
                        sendUBX(setNavAir, len_setNav); // Set Airborne <1G Navigation Mode
                        eRIC_Delay(100);
                        sendUBX(setNMEA, len_setNMEA); // Set NMEA configuration (use GP prefix instead of GN otherwise parsing will fail)
                        eRIC_Delay(100);
                        sendUBX(setGNSS, len_setGNSS); // Set GNSS - causes a reset of the M8!
                        eRIC_Delay(3100);

                        // Clear the UART Rx buffer to erase ubx acknowledgements which would confuse TinyGPS
                        UARTclearRxBuffer();

                        opens_on_altitude = 0; // Make sure opens_on_altitude is initialised
                        val_fix = 0; // Make sure the number of valid fixes is initialised
                        ignore_GNSS = 0; // Clear ignore_GNSS
                    }
                }
            }
            i = 0;
            while(i < 11) // Clear RxData
            {
                RxData[i++] = 'F';
            }
        }


        if (!ignore_GNSS)
        {
            // Encode the serial data from the GNSS
            if(UARTavailable()) // If a character is available
            {
                if(gps_encode(UARTreadRx())) // Encode the character and check if sentence is valid
                {
                    LED_On(); // Flash the LED while processing a new NMEA sentence

                    // If the GNSS sentence is valid
#ifdef GNSS_LOW_POWER
                    if (val_fix == MAX_VAL_FIX) // Check if val_fix has reached MAX_VAL_FIX
                    {
                        // Put CAM_M8 into low power mode
                        // Only do this once, when val_fix == MAX_VAL_FIX
                        sendUBX(confPowerBalanced, len_confPower); // Configure low power mode
                        eRIC_Delay(100); // Wait
                        sendUBX(setLP, len_setLP); // Put CAM_M8 into low power mode
                        eRIC_Delay(1100); // Wait
                        sendUBX(saveConf, len_Conf); // Save configuration
                        eRIC_Delay(1100);
                        UARTclearRxBuffer(); // Clear the UART Rx buffer to erase ubx acknowledgements
                    }
#endif
                    if (val_fix <= MAX_VAL_FIX) // Increment val_fix now that we have a valid sentence
                    {
                        val_fix++; // val_fix will increase until it reaches MAX_VAL_FIX + 1
                    }

                    float gps_alt = gps_f_altitude(); // Get the GNSS altitude
#ifndef TEST_ALT
                    float alt_limit = ((float)alt_lim_10000) * 10000.0f; // Calculate the altitude limit
                    alt_limit = alt_limit + (((float)alt_lim_1000) * 1000.0f);
#else
                    float alt_limit = TEST_ALT_LIM; // Use the test altitude limit
#endif

                    if (gps_alt > alt_limit) // Has the altitude limit been reached?
                    {
                        if (opens_on_altitude < MAX_ALT_OPENS) // Only attempt to open the servo this many times
                        {
                            // altitude limit has been reached so open the servo
#ifdef TEST_PWM
                            eRIC_PWM1_DutyCycle(TEST_PWM_OPEN,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#else
                            eRIC_PWM1_DutyCycle(servo_open_pwm,eRICPWM_OutputMode_Reset_Set); // Set PWM to open
#endif
                            Servo_On(); // Enable 5V for the servo
                            eRIC_Delay(4000); // Wait for four seconds (BLOCKING!)
                            Servo_Off(); // Disable the servo
                            opens_on_altitude++; // Increment the number of attempts
                        }
                    }

                    LED_Off(); // Stop flashing LED
                }
            }
        }
    }
}// End of main

void eRIC_RfDataReceivedInterrupt() // Deal with available received data. This is triggered when interrupt is enabled and a packet is received
{
    while(eRIC_Rxdata_available)
    {
        // Add the received character to RxData
        // Use RxData as a FIFO:
        //   shuffle each character along by one
        //   overwrite the oldest character in RxData[0]
        //   store the new character to RxData[10]
        unsigned int ii = 0;
        while(ii < 10)
        {
            RxData[ii] = RxData[ii+1]; // Shuffle each character along by one
            ii++;
        }
        RxData[10] = eRIC_ReadRfByte(); // Store the new character in RxData[10]
    }
}

#pragma vector= PORT2_VECTOR
__interrupt void PORT2_ISR(void)
{
    // Port 2 Interrupt Service Routine

    // LPRS Pin Mapping
    // Pin 5 = P2.0
    // Pin 4 = P2.1
    // Pin 3 = P2.2
    // Pin 2 = P2.3
    // Pin 1 = P2.4
    // Pin 22 = P2.5

    /*
        http://www.ti.com/product/CC430F5137
        http://www.ti.com/lit/pdf/slau259
        Port 2 interrupt vector value
        00h = No interrupt pending
        02h = Interrupt Source: Port 2.0 interrupt; Interrupt Flag: P2IFG.0; Interrupt Priority: Highest
        04h = Interrupt Source: Port 2.1 interrupt; Interrupt Flag: P2IFG.1
        06h = Interrupt Source: Port 2.2 interrupt; Interrupt Flag: P2IFG.2
        08h = Interrupt Source: Port 2.3 interrupt; Interrupt Flag: P2IFG.3
        0Ah = Interrupt Source: Port 2.4 interrupt; Interrupt Flag: P2IFG.4
        0Ch = Interrupt Source: Port 2.5 interrupt; Interrupt Flag: P2IFG.5
        0Eh = Interrupt Source: Port 2.6 interrupt; Interrupt Flag: P2IFG.6
        10h = Interrupt Source: Port 2.7 interrupt; Interrupt Flag: P2IFG.7; Interrupt Priority: Lowest
     */

    volatile unsigned int function =  P2IV; // Read Interrupt Vector triggered
    switch(function)
    {
    case 0x02: // If interrupted on PORT 2.0 (Pin 5) (+)
        break;
    case 0x04: // If interrupted on PORT 2.1 (Pin 4) (-)
        break;
    case 0x06: // If interrupted on PORT 2.2 (Pin 3) (Open)
        switch_int = OPEN;
        break;
    case 0x08: // If interrupted on PORT 2.3 (Pin 2) (Close)
        switch_int = CLOSE;
        break;
    case 0x0A: // If interrupted on PORT 2.4 (Pin 1)
        // Do nothing - Pin1 is not used
        break;
    case 0x0C: // If interrupted on PORT 2.5 (Pin 22)
        // Do nothing - Pin22 is being used as A2D
        break;
    default:
        break;
    }
}



